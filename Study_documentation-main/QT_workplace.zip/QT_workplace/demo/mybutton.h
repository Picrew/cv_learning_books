#ifndef MYBUTTON_H
#define MYBUTTON_H

#include <QPushButton>

class MyButton : public QPushButton
{
public:
    explicit MyButton(QWidget *parent = nullptr);
    ~MyButton();
signals:

};

#endif // MYBUTTON_H
